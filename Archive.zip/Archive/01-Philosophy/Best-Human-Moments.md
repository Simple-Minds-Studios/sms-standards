# Simple Minds Studios Standards

## The operating manual for the Simple Minds Studios ecosystem.

## This repository defines the principles, language, visual identity, repository standards, AI collaboration guidelines, and design systems used across every Simple Minds Studios project.

If you’re contributing 	to an SMS project—or 	you’re an AI model 		assisting with one—		start here